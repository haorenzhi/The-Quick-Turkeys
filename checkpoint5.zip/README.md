Please access the code using the Google colab link.

After loading, please upload the complainants.csv and narratives.csv from /checkpoint-5/src folder into colab notebook using Upload function.

Then run the code module one by one and get the result of sentiment analysis from the output of last code module.
